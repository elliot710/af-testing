REMOTE_URL="https://github.com/WebKit/WebKit.git"
BASE_BRANCH="main"
BASE_REVISION="e225c278f4c06f451ea92cc68b12986dd2a99979"
