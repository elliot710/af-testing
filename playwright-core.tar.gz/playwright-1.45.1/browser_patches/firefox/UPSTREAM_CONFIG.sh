REMOTE_URL="https://github.com/mozilla/gecko-dev"
BASE_BRANCH="release"
BASE_REVISION="f8704c84a751716bad093b9bdc482db53fe5b3ea"
